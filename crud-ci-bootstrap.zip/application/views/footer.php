<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>

<div align="center">2012</div>
    </div>
    </body>
        </html>